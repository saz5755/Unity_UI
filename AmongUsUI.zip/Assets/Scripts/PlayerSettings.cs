using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EControlType
{
    Mouse,
    KeyboardMouse
}
public class PlayerSettings 
{
    public static EControlType controlType;
   
    
}
